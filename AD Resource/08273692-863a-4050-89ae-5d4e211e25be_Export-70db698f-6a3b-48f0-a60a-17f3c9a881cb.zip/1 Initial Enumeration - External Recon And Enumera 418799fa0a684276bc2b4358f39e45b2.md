# 1. Initial Enumeration - External Recon And Enumeration

Status: Not started
https://www.ired.team/offensive-security-experiments/active-directory-kerberos-abuse: AD SCEURITY NEED TO READ HERE

1. **NSLOOKUP**
    
    ```
    Foresty@htb[/htb]$ nslookup ns1.inlanefreight.com
    Server:		192.168.186.1
    Address:	192.168.186.1#53Non-authoritative answer:
    Name:	ns1.inlanefreight.com
    Address: 178.128.39.165
    
    nslookup ns2.inlanefreight.com
    Server:		192.168.86.1
    Address:	192.168.86.1#53Non-authoritative answer:
    Name:	ns2.inlanefreight.com
    Address: 206.189.119.186
    ```